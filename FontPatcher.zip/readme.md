
# Nerd Fonts

This is the font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Licensing

This script has an MIT license.

The added icons' authors and licenses can be found in the `src/` subdirectory.

## Version
This archive is created from

        commit c5dfa88a1235dff6c1663735a9ec850786bed5c5
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Tue Oct 6 15:34:18 2026 +0200
        
            fetch-archives: Reused latest release metadata if possible
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
